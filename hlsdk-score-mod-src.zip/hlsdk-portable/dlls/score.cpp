/***
*
*	Score mod for Half-Life: kill scoring, friendly-fire penalty and
*	stacking kill-chain combos. See score.h for the rules.
*
***/
#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "player.h"
#include "gamerules.h"
#include "score.h"

cvar_t score_enabled = { "score_enabled", "1" };
cvar_t score_kill_points = { "score_kill_points", "100" };
cvar_t score_friendly_penalty = { "score_friendly_penalty", "500" };
cvar_t score_combo_window = { "score_combo_window", "4.0" };
cvar_t score_combo_max = { "score_combo_max", "10" };

// How often the HUD is refreshed: slowly when idle, faster while the
// score counter is rolling toward a new value.
#define SCORE_HUD_INTERVAL	0.25f
#define SCORE_HUD_ROLL_INTERVAL	0.08f

// Text message channels used by the mod. Channel numbers 0-3 are shared
// with game_text, so these are kept at the high end.
#define SCORE_CHANNEL_STATUS	3
#define SCORE_CHANNEL_POPUP	2

// Stock Half-Life bell sound, so no extra files need to ship with the mod.
#define SCORE_COMBO_SOUND	"buttons/bell1.wav"

void Score_Init( void )
{
	CVAR_REGISTER( &score_enabled );
	CVAR_REGISTER( &score_kill_points );
	CVAR_REGISTER( &score_friendly_penalty );
	CVAR_REGISTER( &score_combo_window );
	CVAR_REGISTER( &score_combo_max );
}

static int Score_ComboWindowIsOpen( CBasePlayer *pPlayer )
{
	return pPlayer->m_iScoreChain > 0 && gpGlobals->time <= pPlayer->m_flScoreChainExpire;
}

static int Score_Multiplier( int iChain )
{
	int iCap = (int)CVAR_GET_FLOAT( "score_combo_max" );

	if( iCap < 1 )
		iCap = 1;

	if( iChain < 1 )
		iChain = 1;

	return iChain > iCap ? iCap : iChain;
}

static const char *Score_ComboName( int iChain )
{
	switch( iChain )
	{
	case 0:
	case 1:
		return "";
	case 2:
		return "DOUBLE KILL";
	case 3:
		return "TRIPLE KILL";
	case 4:
		return "MULTI KILL";
	case 5:
		return "MEGA KILL";
	case 6:
		return "ULTRA KILL";
	case 7:
		return "MONSTER KILL";
	case 8:
		return "RAMPAGE";
	case 9:
		return "UNSTOPPABLE";
	default:
		return "GODLIKE";
	}
}

// Plain fading popup, used for ordinary kills and friendly-fire penalties.
static void Score_Popup( CBasePlayer *pPlayer, const char *szText, byte r, byte g, byte b )
{
	hudtextparms_t params;

	memset( &params, 0, sizeof( params ) );
	params.channel = SCORE_CHANNEL_POPUP;
	params.x = -1.0f;
	params.y = 0.62f;
	params.effect = 0;
	params.r1 = params.r2 = r;
	params.g1 = params.g2 = g;
	params.b1 = params.b2 = b;
	params.a1 = params.a2 = 255;
	params.fadeinTime = 0.0f;
	params.fadeoutTime = 0.4f;
	params.holdTime = 1.4f;

	UTIL_HudMessage( pPlayer, params, szText );
}

// Combo popup: flickers in with a white flash, stays up for a few seconds
// and the colour heats up from yellow to red as the chain grows.
static void Score_ComboPopup( CBasePlayer *pPlayer, int iChain, int iPoints, int iMultiplier )
{
	hudtextparms_t params;
	char szText[96];
	int iHeat = iChain - 2;

	if( iHeat < 0 )
		iHeat = 0;
	if( iHeat > 6 )
		iHeat = 6;

	safe_snprintf( szText, sizeof( szText ), "%s\n+%d   x%d", Score_ComboName( iChain ), iPoints, iMultiplier );
	szText[sizeof( szText ) - 1] = '\0';

	memset( &params, 0, sizeof( params ) );
	params.channel = SCORE_CHANNEL_POPUP;
	params.x = -1.0f;
	params.y = 0.56f;
	params.effect = 1; // flicker
	params.r1 = 255;
	params.g1 = (byte)( 230 - iHeat * 30 );
	params.b1 = (byte)( 60 - iHeat * 8 );
	params.a1 = 255;
	params.r2 = 255; // flash colour
	params.g2 = 255;
	params.b2 = 255;
	params.a2 = 255;
	params.fadeinTime = 0.05f;
	params.fadeoutTime = 0.5f;
	params.holdTime = 2.5f;

	UTIL_HudMessage( pPlayer, params, szText );
}

// Bell "ding" whose pitch climbs with the chain length.
static void Score_ComboSound( CBasePlayer *pPlayer, int iChain )
{
	int iPitch = 100 + ( iChain - 2 ) * 10;

	if( iPitch > 180 )
		iPitch = 180;

	EMIT_SOUND_DYN( ENT( pPlayer->pev ), CHAN_ITEM, SCORE_COMBO_SOUND, 0.9f, ATTN_NONE, 0, iPitch );
}

void Score_Precache( void )
{
	PRECACHE_SOUND( SCORE_COMBO_SOUND );
}

static void Score_UpdateStatus( CBasePlayer *pPlayer )
{
	hudtextparms_t params;
	char szText[96];

	if( pPlayer->m_iHideHUD & HIDEHUD_ALL )
		return;

	memset( &params, 0, sizeof( params ) );
	params.channel = SCORE_CHANNEL_STATUS;
	params.x = 0.82f; // top right, clear of the stock health/ammo HUD
	params.y = 0.04f;
	params.effect = 0;
	params.fadeinTime = 0.0f;
	params.fadeoutTime = 0.1f;
	params.holdTime = SCORE_HUD_INTERVAL * 3.0f;

	if( Score_ComboWindowIsOpen( pPlayer ) )
	{
		float flLeft = pPlayer->m_flScoreChainExpire - gpGlobals->time;

		if( flLeft < 0.0f )
			flLeft = 0.0f;

		safe_snprintf( szText, sizeof( szText ), "SCORE  %d\nCOMBO x%d   %.1fs",
			pPlayer->m_iScoreShown, Score_Multiplier( pPlayer->m_iScoreChain ), flLeft );

		// Orange while a combo is running
		params.r1 = params.r2 = 255;
		params.g1 = params.g2 = 170;
		params.b1 = params.b2 = 40;
	}
	else
	{
		safe_snprintf( szText, sizeof( szText ), "SCORE  %d", pPlayer->m_iScoreShown );

		params.r1 = params.r2 = 255;
		params.g1 = params.g2 = 255;
		params.b1 = params.b2 = 255;
	}

	szText[sizeof( szText ) - 1] = '\0';
	params.a1 = params.a2 = 255;

	UTIL_HudMessage( pPlayer, params, szText );
}

void Score_OnMonsterKilled( CBaseMonster *pVictim, entvars_t *pevAttacker )
{
	char szText[64];

	if( !pVictim || !pevAttacker )
		return;

	if( CVAR_GET_FLOAT( "score_enabled" ) == 0.0f )
		return;

	CBaseEntity *pAttacker = CBaseEntity::Instance( pevAttacker );

	if( !pAttacker || !pAttacker->IsPlayer() )
		return;

	CBasePlayer *pPlayer = (CBasePlayer *)pAttacker;

	// Things that are not worth points either way: unclassified entities,
	// bugs, and the player's own snarks/hornets.
	switch( pVictim->Classify() )
	{
	case CLASS_NONE:
	case CLASS_INSECT:
	case CLASS_PLAYER_BIOWEAPON:
		return;
	}

	int iRelation = pVictim->IRelationship( pPlayer );

	if( iRelation == R_AL )
	{
		// Friendly kill: lose points and break the chain.
		int iPenalty = (int)CVAR_GET_FLOAT( "score_friendly_penalty" );

		if( iPenalty < 0 )
			iPenalty = 0;

		pPlayer->m_iScore -= iPenalty;
		pPlayer->m_iScoreFriendlyKills++;
		pPlayer->m_iScoreChain = 0;
		pPlayer->m_flScoreChainExpire = 0.0f;

		safe_snprintf( szText, sizeof( szText ), "-%d  FRIENDLY KILL", iPenalty );
		szText[sizeof( szText ) - 1] = '\0';
		Score_Popup( pPlayer, szText, 255, 60, 60 );
	}
	else if( iRelation != R_NO )
	{
		// Enemy kill: extend the chain if the timer is still open,
		// otherwise start a new one.
		float flWindow = CVAR_GET_FLOAT( "score_combo_window" );
		int iBase = (int)CVAR_GET_FLOAT( "score_kill_points" );

		if( flWindow < 0.5f )
			flWindow = 0.5f;

		if( iBase < 0 )
			iBase = 0;

		if( Score_ComboWindowIsOpen( pPlayer ) )
			pPlayer->m_iScoreChain++;
		else
			pPlayer->m_iScoreChain = 1;

		pPlayer->m_flScoreChainExpire = gpGlobals->time + flWindow;

		if( pPlayer->m_iScoreChain > pPlayer->m_iScoreBestChain )
			pPlayer->m_iScoreBestChain = pPlayer->m_iScoreChain;

		int iMultiplier = Score_Multiplier( pPlayer->m_iScoreChain );
		int iPoints = iBase * iMultiplier;

		pPlayer->m_iScore += iPoints;
		pPlayer->m_iScoreKills++;

		if( pPlayer->m_iScoreChain >= 2 )
		{
			Score_ComboPopup( pPlayer, pPlayer->m_iScoreChain, iPoints, iMultiplier );
			Score_ComboSound( pPlayer, pPlayer->m_iScoreChain );
		}
		else
		{
			safe_snprintf( szText, sizeof( szText ), "+%d", iPoints );
			szText[sizeof( szText ) - 1] = '\0';
			Score_Popup( pPlayer, szText, 120, 255, 120 );
		}
	}
	else
	{
		// Neutral NPC, nothing to score.
		return;
	}

	// Show the new numbers right away; the counter then rolls to the new
	// total over the next fraction of a second (see Score_Think).
	pPlayer->m_flScoreNextHud = 0.0f;
	Score_UpdateStatus( pPlayer );
	pPlayer->m_flScoreNextHud = gpGlobals->time + SCORE_HUD_ROLL_INTERVAL;
}

// Moves the displayed score toward the real one. Returns true while it is
// still rolling.
static BOOL Score_RollCounter( CBasePlayer *pPlayer )
{
	int iDiff = pPlayer->m_iScore - pPlayer->m_iScoreShown;

	if( iDiff == 0 )
		return FALSE;

	// Close a fixed fraction of the gap each step, at least 1 point, so
	// big combo payouts roll fast and small ones tick up one by one.
	int iStep = iDiff / 5;

	if( iStep == 0 )
		iStep = iDiff > 0 ? 1 : -1;

	pPlayer->m_iScoreShown += iStep;
	return TRUE;
}

void Score_Think( CBasePlayer *pPlayer )
{
	if( !pPlayer || !pPlayer->IsAlive() )
		return;

	if( CVAR_GET_FLOAT( "score_enabled" ) == 0.0f )
		return;

	// The map clock restarts on a level change; don't let a stale value
	// from the previous map freeze the HUD.
	if( pPlayer->m_flScoreNextHud > gpGlobals->time + 1.0f )
		pPlayer->m_flScoreNextHud = 0.0f;

	// Let the combo run out.
	if( pPlayer->m_iScoreChain > 0 && gpGlobals->time > pPlayer->m_flScoreChainExpire )
	{
		pPlayer->m_iScoreChain = 0;
		pPlayer->m_flScoreNextHud = 0.0f;
	}

	if( gpGlobals->time < pPlayer->m_flScoreNextHud )
		return;

	BOOL fRolling = Score_RollCounter( pPlayer );

	pPlayer->m_flScoreNextHud = gpGlobals->time + ( fRolling ? SCORE_HUD_ROLL_INTERVAL : SCORE_HUD_INTERVAL );
	Score_UpdateStatus( pPlayer );
}
