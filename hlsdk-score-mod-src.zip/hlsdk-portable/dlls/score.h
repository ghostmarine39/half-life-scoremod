/***
*
*	Score mod for Half-Life: kill scoring, friendly-fire penalty and
*	stacking kill-chain combos.
*
*	Rules (all tunable through cvars, see score.cpp):
*	  - Killing an enemy NPC scores score_kill_points times the current
*	    combo multiplier.
*	  - Every enemy kill made before the combo timer runs out extends the
*	    chain by one, which raises the multiplier by one (capped at
*	    score_combo_max).
*	  - Killing a friendly NPC (scientists, security guards) costs
*	    score_friendly_penalty points and breaks the chain.
*
***/
#ifndef SCORE_H
#define SCORE_H

class CBaseMonster;
class CBasePlayer;

// Registers the score cvars. Call once from GameDLLInit().
void Score_Init( void );

// Precaches the combo sound. Call from the player's Precache().
void Score_Precache( void );

// Call when a monster dies. Does nothing unless the player is the killer.
void Score_OnMonsterKilled( CBaseMonster *pVictim, entvars_t *pevAttacker );

// Per-frame update for one player: expires combos and refreshes the HUD.
void Score_Think( CBasePlayer *pPlayer );

#endif // SCORE_H
